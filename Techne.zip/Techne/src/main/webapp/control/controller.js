pessoasFormValidation.controller("ctrlPessoasFormValidation", function($scope,
        serviceForm) {

    $scope.listaPessoas = {};
    $scope.pessoa = {};

    //seleciona uma pessoa na tabela
    $scope.selectPessoa = function(pessoa) {

        $scope.pessoa = pessoa;

    };

    //getAllPessoas lista todos os dados
    var listarPessoas = function() {
        serviceForm.getAllPessoas().success(
                function(data, status, headers, config) {

                    $scope.listaPessoas = data;

                }).error(function(data, status, headers, config) {

        });
    };
    listarPessoas();

    //getByIdPessoa
    //savePessoa salva um novo registro de uma pessoa
    $scope.savePessoa = function(pessoa) {
        serviceForm.savePessoa(pessoa).success(
                function(data, status, headers, config) {
                    listarPessoas();
                }).error(function(data, status, headers, config) {

        });
    };

    //updatePessoa atualiza registro de uma pessoa quando selecionado na tabela
    $scope.updatePessoa = function(pessoa) {
        serviceForm.updatePessoa(pessoa).success(
                function(data, status, headers, config) {
                    listarPessoas();
                }).error(function(data, status, headers, config) {

        });
    };

    //deletePessoa remove um registro de uma pessoa quando selecionado na tabela
    $scope.deletePessoa = function(pessoa) {
        serviceForm.deletePessoa(pessoa.id).success(
                function(data, status, headers, config) {
                    listarPessoas();
                }).error(function(data, status, headers, config) {

        });
    };
});



pessoasFormValidation.factory("serviceForm", function(config, $http) {

    var _getAllPessoas = function() {
        return $http
                .get("Techne/pessoa");
    };

    var _getByIdPessoa = function(id) {
        return $http
                .get("Techne/pessoa/" + id);
    };


    var _savePessoa = function(pessoa) {
        return $http.post("Techne/pessoa/salvar", angular.toJson(pessoa));
    };

    var _updatePessoa = function(pessoa) {
        return $http.put("Techne/pessoa/" + pessoa.id, angular.toJson(pessoa));
    };

    var _deletePessoa = function(id) {
        return $http.delete("Techne/pessoa/" + id);
    };

    return {
        getAllPessoas: _getAllPessoas,
        getByIdPessoa: _getByIdPessoa,
        savePessoa: _savePessoa,
        updatePessoa: _updatePessoa,
        deletePessoa: _deletePessoa,
       
    };

});



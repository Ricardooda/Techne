package br.com.techne.rs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.ws.rs.*;
import static javax.ws.rs.HttpMethod.*;
import javax.ws.rs.core.MediaType;

@Path("/pessoa")
public class CadastroPessoa implements Serializable {

    @Inject
    private CadastroPessoaServico cadastroPessoaServico;

    @GET
    @Produces("application/xml")
    public List<Pessoa> getPessoa() {
        return cadastroPessoaServico.getPessoa();

    }

    @POST
    public Pessoa salva(Pessoa pessoa) {
        return cadastroPessoaServico.salva(pessoa);

    }

    @PUT
    public Pessoa atualizar(Pessoa pessoa) {
        return cadastroPessoaServico.atualizar(pessoa);

    }

    @DELETE
    @Path("/{id}")
    public void excluir(@PathParam("id") String id) {
        Pessoa pessoa = new Pessoa();
        pessoa.setId(id);
        cadastroPessoaServico.excluir(pessoa);

    }

}

package br.com.techne.rs;

import java.io.Serializable;
import java.util.List;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


public class CadastroPessoaServico implements Serializable {

    @Inject
    private PessoaDAO pessoaDAO;
    
    List<Pessoa> getPessoa() {
        return pessoaDAO.getPessoa();
    }

    Pessoa salva(Pessoa pessoa) {
        return pessoaDAO.salvar(pessoa);
    }

    Pessoa atualizar(Pessoa pessoa) {
        return null;
    }

    void excluir(Pessoa pessoa) {
       
    }
    
 
}

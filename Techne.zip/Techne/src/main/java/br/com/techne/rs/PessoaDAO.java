
package br.com.techne.rs;

import java.io.Serializable;
import java.util.List;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

public class PessoaDAO implements Serializable{

    @PersistenceContext(unitName="Techne")
            private EntityManager entityManager;
    List<Pessoa> getPessoa() {
        Query query = entityManager.createQuery("from pessoa");
        return query.getResultList();
        
    }

    public Pessoa salvar(Pessoa pessoa) {
        entityManager.persist(pessoa);
        return pessoa;
       
    }
    public void excluir(Pessoa pessoa){
        Pessoa pessoaMerge = entityManager.merge(pessoa);
        entityManager.remove(pessoa);
}
    public void atualizar(Pessoa pessoa){
        Pessoa pessoaMerge = entityManager.merge(pessoa);
        entityManager.persist(pessoa);
}
}